import React from 'react';
import './Welcome.css'; // Make sure this path is correct
import useSound from 'use-sound';
import clickSound from '../assets/button_click.wav';

const Welcome = ({ onPlay }) => {
  const [playClick] = useSound(clickSound);

  const handlePlayClick = () => {
    playClick();       // Play the click sound
    onPlay();          // Then trigger your play handler
  };
  return (
    <div className="welcome-screen animated-background">
       <h1>Welcome to <span className="highlight">Healthy Mind</span> 💚</h1>
      <button className="play-button bounce" onClick={handlePlayClick}>Play</button>
    </div>
  );
};

export default Welcome;
