// src/components/About.jsx
import React from 'react';
import './About.css'; // optional: for styling

const About = () => {
  return (
    <div className="about-screen">
      <h1>About This Project 💡</h1>
      <p>This is a fun and educational platform for improving emotional awareness using CN concepts. 🧠💬</p>
      <p>Built with React, React Router, and love! 💚</p>
    </div>
  );
};

export default About;
