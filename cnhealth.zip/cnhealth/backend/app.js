const express = require("express");
const http = require("http");
const socketIo = require("socket.io");
const cors = require("cors");
const app = express();
const chatroomSocket = require("./chatroomSocket");
const server = http.createServer(app);
app.use(cors());
const io = socketIo(server, {
   cors: {
     origin: "http://localhost:5173",
     methods: ["GET", "POST"],
   },
});
chatroomSocket(io);
const PORT = process.env.PORT || 5000;

const questions =[
  {
    question: "Which emotion is often felt when something unfair happens?",
    answers: [
      { text: "Anger", correct: true },
      { text: "Happiness", correct: false },
      { text: "Surprise", correct: false },
      { text: "Joy", correct: false },
    ],
  },
  {
    question: "Which action shows emotional intelligence?",
    answers: [
      { text: "Understanding how others feel", correct: true },
      { text: "Judging others quickly", correct: false },
      { text: "Ignoring your feelings", correct: false },
      { text: "Always pretending to be happy", correct: false },
    ],
  },
  {
    question: "What does it mean to feel empathy?",
    answers: [
      { text: "To share and understand someone else’s feelings", correct: true },
      { text: "To feel sorry for yourself", correct: false },
      { text: "To ignore emotions", correct: false },
      { text: "To argue with someone", correct: false },
    ],
  },
  {
    question: "What can help calm strong emotions?",
    answers: [
      { text: "Taking deep breaths", correct: true },
      { text: "Yelling", correct: false },
      { text: "Avoiding the issue", correct: false },
      { text: "Watching scary movies", correct: false },
    ],
  },
  {
    question: "How can you tell someone is feeling sad?",
    answers: [
      { text: "They may seem quiet or withdrawn", correct: true },
      { text: "They smile constantly", correct: false },
      { text: "They jump around excitedly", correct: false },
      { text: "They laugh loudly", correct: false },
    ],
  },
  {
    question: "Which emotion helps you realize you’ve made a mistake?",
    answers: [
      { text: "Guilt", correct: true },
      { text: "Pride", correct: false },
      { text: "Fear", correct: false },
      { text: "Surprise", correct: false },
    ],
  },
  {
    question: "What is a good way to respond when someone is crying?",
    answers: [
      { text: "Offer a tissue and ask if they’re okay", correct: true },
      { text: "Laugh at them", correct: false },
      { text: "Tell them to stop", correct: false },
      { text: "Ignore them", correct: false },
    ],
  },
  {
    question: "What emotion might you feel before taking a test?",
    answers: [
      { text: "Nervousness", correct: true },
      { text: "Excitement", correct: false },
      { text: "Joy", correct: false },
      { text: "Confusion", correct: false },
    ],
  },
  {
    question: "What can journaling help you with emotionally?",
    answers: [
      { text: "Understanding and processing your feelings", correct: true },
      { text: "Becoming emotionless", correct: false },
      { text: "Forgetting everything", correct: false },
      { text: "Avoiding problems", correct: false },
    ],
  },
  {
    question: "Which emotion do people often feel when they’re left out?",
    answers: [
      { text: "Loneliness", correct: true },
      { text: "Happiness", correct: false },
      { text: "Anger", correct: false },
      { text: "Excitement", correct: false },
    ],
  },
  {
    question: "Why is it important to name your emotions?",
    answers: [
      { text: "It helps you manage them better", correct: true },
      { text: "It makes them go away", correct: false },
      { text: "It impresses people", correct: false },
      { text: "It helps you forget them", correct: false },
    ],
  },
  {
    question: "Which emotion do you feel when someone appreciates your effort?",
    answers: [
      { text: "Pride", correct: true },
      { text: "Guilt", correct: false },
      { text: "Fear", correct: false },
      { text: "Sadness", correct: false },
    ],
  },
  {
    question: "What’s an unhealthy way to deal with anger?",
    answers: [
      { text: "Yelling or hitting", correct: true },
      { text: "Taking deep breaths", correct: false },
      { text: "Talking about it", correct: false },
      { text: "Taking a walk", correct: false },
    ],
  },
  {
    question: "Which of the following helps build emotional awareness?",
    answers: [
      { text: "Mindfulness and self-reflection", correct: true },
      { text: "Ignoring your emotions", correct: false },
      { text: "Always staying busy", correct: false },
      { text: "Blaming others", correct: false },
    ],
  },
  {
    question: "How does practicing gratitude affect your emotions?",
    answers: [
      { text: "It increases positive feelings", correct: true },
      { text: "It makes you feel guilty", correct: false },
      { text: "It causes sadness", correct: false },
      { text: "It creates fear", correct: false },
    ],
  },
  {
    question: "Which emotion can lead to personal growth if handled well?",
    answers: [
      { text: "Failure-related disappointment", correct: true },
      { text: "Jealousy", correct: false },
      { text: "Laziness", correct: false },
      { text: "Apathy", correct: false },
    ],
  },
  {
    question: "Why is it helpful to talk to someone when you're feeling upset?",
    answers: [
      { text: "It helps you feel supported and understood", correct: true },
      { text: "It makes the emotion worse", correct: false },
      { text: "It wastes time", correct: false },
      { text: "It proves you’re weak", correct: false },
    ],
  },
  {
    question: "What’s a sign of high emotional intelligence?",
    answers: [
      { text: "Managing your reactions during conflict", correct: true },
      { text: "Winning arguments", correct: false },
      { text: "Ignoring others' opinions", correct: false },
      { text: "Crying often", correct: false },
    ],
  },
  {
    question: "Which activity can boost your mood naturally?",
    answers: [
      { text: "Exercising", correct: true },
      { text: "Overthinking", correct: false },
      { text: "Staying indoors all day", correct: false },
      { text: "Skipping meals", correct: false },
    ],
  },
  {
    question: "Which emotion is usually felt when something unexpected and good happens?",
    answers: [
      { text: "Surprise", correct: true },
      { text: "Guilt", correct: false },
      { text: "Disgust", correct: false },
      { text: "Boredom", correct: false },
    ],
  }
]
;


const rooms = {};

io.on("connection", (socket) => {
  console.log("A user connected");

  socket.on("joinRoom", (room, name) => {
    socket.join(room);
    io.to(room).emit("message", `${name} has joined the game!`);
    if (!rooms[room]) {
      rooms[room] = {
        players: [],
        currentQuestion: null,
        correctAnswer: null,
        questionTimeout: null,
        shouldAskNewQuestion: true,
      };
    }
    // to make score zero
  //   if(rooms[room]){
  //   rooms[room].players.forEach((player) => {
  //     player.score = 0;
  //   });
  // }
  // rooms[room].players.push({ id: socket.id, name,score: 0  });
    rooms[room].players.push({ id: socket.id, name });

    if (!rooms[room].currentQuestion) {
      askNewQuestion(room);
    }
  });

  socket.on("submitAnswer", (room, answerIndex) => {
    const currentPlayer = rooms[room].players.find(
      (player) => player.id === socket.id
    );

    if (currentPlayer) {
      const correctAnswer = rooms[room].correctAnswer;
      const isCorrect = correctAnswer !== null && correctAnswer === answerIndex;
      currentPlayer.score = isCorrect
        ? (currentPlayer.score || 0) + 1
        : (currentPlayer.score || 0) - 1;

      clearTimeout(rooms[room].questionTimeout);

      io.to(room).emit("answerResult", {
        playerName: currentPlayer.name,
        isCorrect,
        correctAnswer,
        scores: rooms[room].players.map((player) => ({
          name: player.name,
          score: player.score || 0,
        })),
      });

      const winningThreshold = 5;
      const winner = rooms[room].players.find(
        (player) => (player.score || 0) >= winningThreshold
      );

      if (winner) {
        io.to(room).emit("gameOver", { winner: winner.name });
        delete rooms[room];
      } else {
        askNewQuestion(room);
      }
    }
  });

  socket.on("disconnect", () => {
    for (const room in rooms) {
      rooms[room].players = rooms[room].players.filter(
        (player) => player.id !== socket.id
      );
    }

    console.log("A user disconnected");
  });
});

function askNewQuestion(room) {
  if (rooms[room].players.length === 0) {
    clearTimeout(rooms[room].questionTimeout);
    delete rooms[room];
    return;
  }

  const randomIndex = Math.floor(Math.random() * questions.length);
  const question = questions[randomIndex];
  rooms[room].currentQuestion = question;
  const correctAnswerIndex = question.answers.findIndex(
    (answer) => answer.correct
  );

  rooms[room].correctAnswer = correctAnswerIndex;
  rooms[room].shouldAskNewQuestion = true;
  io.to(room).emit("newQuestion", {
    question: question.question,
    answers: question.answers.map((answer) => answer.text),
    timer: 10,
  });

  rooms[room].questionTimeout = setTimeout(() => {
    io.to(room).emit("answerResult", {
      playerName: "No one",
      isCorrect: false,
      correctAnswer: rooms[room].correctAnswer,
      scores: rooms[room].players.map((player) => ({
        name: player.name,
        score: player.score || 0,
      })),
    });

    askNewQuestion(room);
  }, 10000);
}

server.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
